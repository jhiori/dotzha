export interface DataCo {
    id_co?: number
    name_co?: string
    subName_co?: string
    slogan_co?: string
    avatar_co?: string
    imgUrl_co?: string
    desc_co?: string
    redirect?: string
}