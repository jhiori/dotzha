export interface UserLogin {
    idUser?: number;
    user?: string;
    nameUser?: string;
    pass?: string;
    token?: string;
    activeUser?: number;
}